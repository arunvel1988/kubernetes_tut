#!/usr/bin/env bash

kind create cluster --config kind-multi-node.yaml

