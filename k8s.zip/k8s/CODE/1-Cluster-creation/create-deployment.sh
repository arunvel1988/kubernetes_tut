#!/usr/bin/env bash

set -x

kubectl create deployment kiada --image=luksa/kiada:0.1

